#!/usr/bin/python

import cgi
import datamodel
import view
from os import environ
import http.cookies

def getValueFromCookie(keyCookie):
	if environ.get("HTTP_COOKIE") is not None:
		cookie = http.cookies.SimpleCookie()
		cookie_string = environ.get("HTTP_COOKIE")
		cookie.load(cookie_string)
		
		if cookie.get(keyCookie) is not None:
			valuesCookie = str(cookie.get(keyCookie)).split('=')
			return valuesCookie[1]
	
	return ""

def getCurrentUserName():
	return getValueFromCookie("UserName")

def checkUserLogin(dm):
	return dm.getAccessID(getValueFromCookie("UserID")) > 0

def delUserID(dm):
	print("Set-Cookie:UserName=0;")
	print("Set-Cookie:UserID=0;")
	dm.delUserKey(getValueFromCookie("UserID"))

def setUserID(dm, username):
	print("Set-Cookie:UserName="+username+";")
	print("Set-Cookie:UserID="+dm.createUserKey()+";")

def setAttempts(numAttempts):
	print("Set-Cookie:UserAttempts="+str(numAttempts)+";")

def getMaxAttempts():
	return(5)

def setMaxAttempts():
	setAttempts(getMaxAttempts())

def getAttempts():
	try:
		attempts_str = getValueFromCookie("UserAttempts")
		maxAttempts = getMaxAttempts()

		if attempts_str == "":
			setAttempts(maxAttempts)
			return maxAttempts

		attempts = int(attempts_str)
		if attempts > maxAttempts:
			setAttempts(maxAttempts)

		return attempts
	except Exception:
		return 0		

dataModelDB = datamodel.DataModelDB()
params = cgi.FieldStorage()

try:
	loginOn = int(params.getvalue("login"))
except Exception:
	loginOn = 0

try:
	actionIn = ""+params.getvalue("action")
except Exception:
	actionIn = "none"

allMenuItems = dataModelDB.getAllMenuItems()

try:
	# Show login form
	if loginOn == 1:
		delUserID(dataModelDB)
		print(view.getLoginPage(""))

	# Check login info
	elif loginOn == 2:
		username = params.getvalue("user")
		password = params.getvalue("password")

		if dataModelDB.checkCredential(username, password) and getAttempts() > 0:
			setMaxAttempts()
			setUserID(dataModelDB, username)
			print(view.getMainEditPage(allMenuItems, dataModelDB.getDictContentByMenuItemID(allMenuItems[0][0]), allMenuItems[0][0], 0))
		elif getAttempts() <= 0:
			print(view.getLoginPage("Too many attempts to login!"))
		else:
			setAttempts(getAttempts()-1)
			print(view.getLoginPage("Wrong user name or password!"))

	# Show main site
	elif actionIn == "none":
		menuItemID = params.getvalue("id")
		showContent = dataModelDB.getContentByMenuItemID(menuItemID)
		if showContent == "":
			raise Exception("Not found id")
		else:
			print(view.getMainPage(allMenuItems, showContent))

	# Show menu item in edit
	elif actionIn == "show" and checkUserLogin(dataModelDB):
		menuItemID = int(params.getvalue("id"))
		print(view.getMainEditPage(allMenuItems, dataModelDB.getDictContentByMenuItemID(menuItemID), menuItemID, 0))

	# New menu item
	elif actionIn == "newmi" and checkUserLogin(dataModelDB):
		dataModelDB.createNewMenuItem()
		allMenuItems = dataModelDB.getAllMenuItems()
		print(view.getMainEditPage(allMenuItems, dataModelDB.getDictContentByMenuItemID(allMenuItems[0][0]), allMenuItems[0][0], 0))

	# New material
	elif actionIn == "newma" and checkUserLogin(dataModelDB):
		menuitemID = int(params.getvalue("id"))
		dataModelDB.createNewMaterial(menuitemID)
		print(view.getMainEditPage(allMenuItems, dataModelDB.getDictContentByMenuItemID(menuitemID), menuitemID, 0))

	# Delete menu item
	elif actionIn == "delmi" and checkUserLogin(dataModelDB):
		menuItemID = int(params.getvalue("id"))
		dataModelDB.delMenuItem(menuItemID)
		allMenuItems = dataModelDB.getAllMenuItems()
		print(view.getMainEditPage(allMenuItems, dataModelDB.getDictContentByMenuItemID(allMenuItems[0][0]), allMenuItems[0][0], 0))		

	# Delete material
	elif actionIn == "delma" and checkUserLogin(dataModelDB):
		menuItemID = int(params.getvalue("mid"))
		materialID = int(params.getvalue("cid"))
		dataModelDB.delContent(materialID)
		print(view.getMainEditPage(allMenuItems, dataModelDB.getDictContentByMenuItemID(menuItemID), menuItemID, 0))

	# Edit material 
	elif actionIn == "edit" and checkUserLogin(dataModelDB):
		menuItemID = int(params.getvalue("mid"))
		materialID = int(params.getvalue("cid"))
		print(view.getMainEditPage(allMenuItems, dataModelDB.getDictContentByMenuItemID(menuItemID), menuItemID, materialID))		

	# Save changes after edit
	elif actionIn == "save" and checkUserLogin(dataModelDB):
		menuItemID = int(params.getvalue("menuitemid"))
		menuitemName = str(params.getvalue("menuitemname"))
		try:
			materialID = int(params.getvalue("contentid"))
			valueContent = str(params.getvalue("contentvalue"))
		except Exception:
			materialID = 0
			valueContent = ""
		dataModelDB.saveChanges(menuItemID, menuitemName, materialID, valueContent)
		allMenuItems = dataModelDB.getAllMenuItems()
		print(view.getMainEditPage(allMenuItems, dataModelDB.getDictContentByMenuItemID(menuItemID), menuItemID, 0))

	# Left menu item
	elif actionIn == "leftmi" and checkUserLogin(dataModelDB):
		menuItemID = int(params.getvalue("id"))

		dataModelDB.leftMenuItem(menuItemID)

		allMenuItems = dataModelDB.getAllMenuItems()
		print(view.getMainEditPage(allMenuItems, dataModelDB.getDictContentByMenuItemID(menuItemID), menuItemID, 0))

	# Right menu item
	elif actionIn == "rightmi" and checkUserLogin(dataModelDB):
		menuItemID = int(params.getvalue("id"))

		dataModelDB.rightMenuItem(menuItemID)

		allMenuItems = dataModelDB.getAllMenuItems()
		print(view.getMainEditPage(allMenuItems, dataModelDB.getDictContentByMenuItemID(menuItemID), menuItemID, 0))

	# show edit pass page
	elif actionIn == "showps" and checkUserLogin(dataModelDB):
		allMenuItems = dataModelDB.getAllMenuItems()
		print(view.getChangePasswordPage(allMenuItems))

	# save new password
	elif actionIn == "saveps" and checkUserLogin(dataModelDB):
		newpass = params.getvalue("newpass")

		dataModelDB.changeUserPass(getCurrentUserName(), newpass)

		allMenuItems = dataModelDB.getAllMenuItems()
		print(view.getMainEditPage(allMenuItems, dataModelDB.getDictContentByMenuItemID(allMenuItems[0][0]), allMenuItems[0][0], 0))

	else:
		raise Exception("No case is on!")
except Exception as e:
	delUserID(dataModelDB)
	print(view.getMainPage(allMenuItems, dataModelDB.getDefaultContent())+"\n\n<!-- Exception was raised: "+str(e)+" -->")
finally:
	dataModelDB.close()