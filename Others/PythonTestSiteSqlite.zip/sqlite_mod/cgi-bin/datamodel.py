#!/usr/bin/python

import sqlite3
import random
import string
import hashlib

class DataModelDB:
	def __init__(self, dbpath='db/mainstorage.db'):
		self.dbConnect = sqlite3.connect(dbpath)
		self.dbCursor = self.dbConnect.cursor()

	def close(self):
		self.dbCursor.close()
		self.dbConnect.close()

	def removeSchemeDB(self):
		self.dbCursor.execute("drop table menuitems_py")
		self.dbCursor.execute("drop table content_py")
		self.dbCursor.execute("drop table users_py")
		self.dbCursor.execute("drop table access_py")

	def installSchemeDB(self):
		self.dbCursor.execute("""
			create table menuitems_py (
				menuitem_id integer primary key, 
				name text not null, 
				order_num int)	
			""")

		self.dbCursor.execute("""
			create table content_py (
				content_id integer primary key, 
				menuitem_id integer,
				value longtext, 
				order_num int)	
			""")

		self.dbCursor.execute("""
			create table users_py (
				user_id integer primary key, 
				username text not null,
				password text not null)	
			""")

		self.dbCursor.execute("""
			create table access_py (
				user_key varchar(24) not null primary key, 
				datetime_login datetime,
				datetime_expire datetime)	
			""")

		self.dbCursor.execute("insert into menuitems_py(name, order_num) values('News',1)")
		self.dbCursor.execute("insert into menuitems_py(name, order_num) values('Features',2)")
		self.dbCursor.execute("insert into menuitems_py(name, order_num) values('Contacts',3)")

		self.dbCursor.execute("insert into content_py(menuitem_id, value, order_num) values(1,'<p>Some content about News 1.</p>',1)")
		self.dbCursor.execute("insert into content_py(menuitem_id, value, order_num) values(2,'<p>Some content about Features.</p>',1)")
		self.dbCursor.execute("insert into content_py(menuitem_id, value, order_num) values(3,'<p>Some content about Contacts.</p>',1)")
		self.dbCursor.execute("insert into content_py(menuitem_id, value, order_num) values(1,'<p>Some content about News 2.</p>',2)")

		self.dbCursor.execute("insert into users_py(username, password) values('admin',?)", (hashlib.sha224(b'admin').hexdigest(),))

		self.dbConnect.commit()

	def changeUserPass(self, username, newPass):
		self.dbCursor.execute("update users_py set password=? where username=?",(hashlib.sha224(newPass.encode()).hexdigest(), username))
		self.dbConnect.commit()

	def getAllMenuItems(self):
		resAllMenuItems = []

		self.dbCursor.execute("select menuitem_id, name from menuitems_py order by order_num")
		for row in self.dbCursor.fetchall():
			resAllMenuItems.append((int(row[0]), row[1]));

		return resAllMenuItems

	def getContentByMenuItemID(self, menuitemID):
		resContent = ""

		self.dbCursor.execute("select value from content_py where menuitem_id=? order by order_num", (menuitemID, ))
		for row in self.dbCursor.fetchall():
			resContent += row[0]

		return resContent

	def getDictContentByMenuItemID(self, menuitemID):
		resDictContent = {}

		self.dbCursor.execute("select content_id, value from content_py where menuitem_id=? order by order_num", (menuitemID, ))
		for row in self.dbCursor.fetchall():
			resDictContent.update({int(row[0]):row[1]})

		return resDictContent

	def getDefaultContent(self):
		return self.getContentByMenuItemID(1)

	def checkCredential(self, uname, passw):
		self.dbCursor.execute("select username, password from users_py")
		for row in self.dbCursor.fetchall():
			if row[0] == uname:
				return hashlib.sha224(passw.encode()).hexdigest() == row[1]

		return 0>1	

	def createNewMenuItem(self):
		self.dbCursor.execute("select max(order_num) from menuitems_py")
		max_order = 0
		try:
			row = self.dbCursor.fetchone()
			max_order = int(row[0])+1
		except Exception:
			max_order = 1

		self.dbCursor.execute("insert into menuitems_py (name, order_num) values('Default Menu Item', ?)", (max_order, ))
		self.dbConnect.commit()

	def createNewMaterial(self, menuitemID):
		self.dbCursor.execute("select max(order_num) from content_py where menuitem_id=?", (menuitemID, ))
		max_order = 0
		try:
			row = self.dbCursor.fetchone()
			max_order = int(row[0])+1		
		except Exception:
			max_order = 1

		self.dbCursor.execute("insert into content_py (menuitem_id, value, order_num) values(?, 'Default Material.', ?)", (menuitemID, max_order))
		self.dbConnect.commit()

	def saveChanges(self, menuitemID, menuitemNewName, contentID, contentValue):
		self.dbCursor.execute("update menuitems_py set name=? where menuitem_id=?", (menuitemNewName, menuitemID))
		if contentID > 0:
			self.dbCursor.execute("update content_py set value=? where content_id=?", (contentValue, contentID))

		self.dbConnect.commit()

	def delMenuItem(self, menuitemID):
		self.dbCursor.execute("delete from menuitems_py where menuitem_id=?", (menuitemID, ))
		self.dbCursor.execute("delete from content_py where menuitem_id=?", (menuitemID, ))
		self.dbConnect.commit()

	def delContent(self, contentID):
		self.dbCursor.execute("delete from content_py where content_id=?", (contentID, ))
		self.dbConnect.commit()

	def createUserKey(self):
		genKey = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(12))
		self.dbCursor.execute("insert into access_py (user_key, datetime_login, datetime_expire) values(?, date('now'), DATETIME(date('now'), '+60 minutes'))", (genKey, ))
		self.dbConnect.commit()

		return genKey

	def getAccessID(self, userKey):
		self.dbCursor.execute("delete from access_py where not(date('now') between datetime_login and datetime_expire)")
		self.dbCursor.execute("select user_key from access_py")
		for row in self.dbCursor.fetchall():
			if str(row[0]).upper() == str(userKey).upper():
				return 1

		self.dbConnect.commit()

		return 0

	def delUserKey(self, userKey):
		accessID = self.getAccessID(userKey)

		if accessID > 0 and userKey.find(" ") < 0:
			self.dbCursor.execute("delete from access_py where user_key=?", (str(userKey).upper(), ))

		self.dbConnect.commit()

	def getOrderFromMenuItem(self, menuitemID):
		resOrder = 0
		self.dbCursor.execute("select order_num from menuitems_py where menuitem_id=?", (menuitemID, ))
		row = self.dbCursor.fetchone()
		resOrder = int(row[0])

		return resOrder

	def leftMenuItem(self, menuitemID):
		curOrder = self.getOrderFromMenuItem(menuitemID)
		leftOrder = 0
		leftMenuItemID = 0
		offsetOrder = 1000

		self.dbCursor.execute("select menuitem_id, order_num from menuitems_py where order_num<?", (curOrder, ))
		for row in self.dbCursor.fetchall():
			tempOrder = int(row[1])
			if abs(tempOrder-curOrder) != 0 and abs(tempOrder-curOrder) < offsetOrder:
				offsetOrder = abs(tempOrder-curOrder)
				leftOrder = tempOrder
				leftMenuItemID = int(row[0])

		if leftMenuItemID > 0:
			self.dbCursor.execute("update menuitems_py set order_num=? where menuitem_id=?", (leftOrder, menuitemID))
			self.dbCursor.execute("update menuitems_py set order_num=? where menuitem_id=?", (curOrder, leftMenuItemID))
			self.dbConnect.commit()

	def rightMenuItem(self, menuitemID):
		curOrder = self.getOrderFromMenuItem(menuitemID)
		rightOrder = 0
		rightMenuItemID = 0
		offsetOrder = 1000

		self.dbCursor.execute("select menuitem_id, order_num from menuitems_py where order_num>?", (curOrder, ))
		for row in self.dbCursor.fetchall():
			tempOrder = int(row[1])
			if abs(tempOrder-curOrder) != 0 and abs(tempOrder-curOrder) < offsetOrder:
				offsetOrder = abs(tempOrder-curOrder)
				rightOrder = tempOrder
				rightMenuItemID = int(row[0])

		if rightMenuItemID > 0:
			self.dbCursor.execute("update menuitems_py set order_num=? where menuitem_id=?", (rightOrder, menuitemID))
			self.dbCursor.execute("update menuitems_py set order_num=? where menuitem_id=?", (curOrder, rightMenuItemID))
			self.dbConnect.commit()


if __name__ == '__main__':	
	print("Content-type: text/html\n\n<html>\n<head><title>ReInstall</title></head>\n<body>\n<p>Initializing...</p>")
	dataModel = DataModelDB()
	try:
		dataModel.removeSchemeDB()
		print("<p>Installing scheme...</p>\n")
		dataModel.installSchemeDB()
		dataModel.changeUserPass(1,'admin')
		print("<p>Done.</p>\n")
	finally:
		dataModel.close()
	print("</body>\n</html>")
	
	
