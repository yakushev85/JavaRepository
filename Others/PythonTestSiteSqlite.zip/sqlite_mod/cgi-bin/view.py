#!/usr/bin/python

def getMainPage(menuitems, content):
	resHeader = "Content-type: text/html\n\n"
	resHTML = ""

	fileTemplate = open('template.html', "r")
	for line in fileTemplate:
		resHTML += line

	menuitemsHTML = ""
	for (menuitemID, menuitemValue) in menuitems:
		menuitemsHTML += "<li><a href=\""+conLocation+"?id="+str(menuitemID)+"\">"+menuitemValue+"</a></li>"

	return (resHeader+resHTML) % (menuitemsHTML, content)

def getLoginPage(errormsg):
	resHTML = "Content-type: text/html\n\n"

	fileLogin = open('login.html', "r")
	for line in fileLogin:
		resHTML += line

	return resHTML % errormsg

def getChangePasswordPage(menuitems):
	resHeader = "Content-type: text/html\n\n"
	resHTML = ""

	fileTemplate = open("template.html", "r")
	for line in fileTemplate:
		resHTML += line

	menuitemsHTML = ""
	for (menuitemID, menuitemValue) in menuitems:
		menuitemsHTML += "<li><a href=\""+conLocation+"?action=show&id="+str(menuitemID)+"\">"+menuitemValue+"</a></li>"
	
	contentsHTML = "<form method=\"post\" action=\""+conLocation+"\" class=\"form-inline\" id=\"passform\">"
	contentsHTML += "<input type=\"hidden\" name=\"action\" value=\"saveps\">"
	contentsHTML += "<div class=\"form-group\"><label>New password</label>   "
	contentsHTML += "<input type=\"password\" id=\"newpass\" name=\"newpass\" class=\"form-control input-lg\" placeholder=\"New password\"></div>   "
	contentsHTML += "<div class=\"form-group\"><label>Reenter new password</label>   "
	contentsHTML += "<input type=\"password\" id=\"renewpass\" name=\"renewpass\" class=\"form-control input-lg\" placeholder=\"New password\"></div>   "
	contentsHTML += "<input type=\"button\" value=\"Save\" class=\"btn btn-primary\" onClick=\""+\
	"if ($('#newpass').val() == $('#renewpass').val()) {$('#passform').submit()} else {alert('Please reenter password!');}\">"
	contentsHTML += "</form>"

	return (resHeader+resHTML) % (menuitemsHTML, contentsHTML)

def getMainEditPage(menuitems, contents, editmenuitemID, editcontentID):
	resHeader = "Content-type: text/html\n\n"
	resHTML = ""

	fileTemplate = open("template.html", "r")
	for line in fileTemplate:
		resHTML += line

	menuitemsHTML = ""
	editmenuitemName = ""
	for (menuitemID, menuitemValue) in menuitems:
		menuitemsHTML += "<li><a href=\""+conLocation+"?action=show&id="+str(menuitemID)+"\">"+menuitemValue+"</a></li>"
		if menuitemID == editmenuitemID:
			editmenuitemName = menuitemValue

	contentsHTML = "<form method=\"post\" action=\""+conLocation+"\">"
	contentsHTML += "<div>"
	contentsHTML += "<a href=\""+conLocation+"?action=newmi\" class=\"btn btn-primary\">Create new menu item</a>     "
	contentsHTML += "<a href=\""+conLocation+"?action=newma&id="+str(editmenuitemID)+"\" class=\"btn btn-primary\">Create new material</a>     "
	contentsHTML += "<a href=\""+conLocation+"?action=showps\" class=\"btn btn-warning\">Change password</a>     "
	contentsHTML += "<a href=\""+conLocation+"?login=1\" class=\"btn btn-warning\">Log out</a>     "
	contentsHTML += "<input type=\"submit\" class=\"btn btn-info\" value=\"Apply and Save\">"

	contentsHTML += "<hr>"
	contentsHTML += "<input type=\"hidden\" name=\"action\" value=\"save\">"
	contentsHTML += "<input type=\"hidden\" name=\"menuitemid\" value=\""+str(editmenuitemID)+"\">"
	contentsHTML += "<div class=\"form-group\"><label>Current menu item:</label>  "
	contentsHTML += "<input type=\"text\" name=\"menuitemname\" size= \"30\"value=\""+editmenuitemName+"\">  "
	contentsHTML += "<a href=\""+conLocation+"?action=delmi&id="+str(editmenuitemID)+"\" class=\"btn btn-danger\">Delete</a>   "
	contentsHTML += "<a href=\""+conLocation+"?action=leftmi&id="+str(editmenuitemID)+"\" class=\"btn btn-info\">Left</a>   "
	contentsHTML += "<a href=\""+conLocation+"?action=rightmi&id="+str(editmenuitemID)+"\" class=\"btn btn-info\">Right</a>"
	contentsHTML += "</div></div>"
	
	for contentID, contentValue in contents.items():
		if contentID == editcontentID:
			contentsHTML += "<hr>"
			contentsHTML += "<input type=\"hidden\" name=\"contentid\" value=\""+str(contentID)+"\">"
			contentsHTML += "<textarea class=\"form-control\" rows=\"15\" name=\"contentvalue\">"+contentValue+"</textarea>"
		else:
			contentsHTML += "<hr>"+contentValue
			contentsHTML += "<p><a href=\""+conLocation+"?action=edit&cid="+str(contentID)+"&mid="+str(editmenuitemID)+\
			"\" class=\"btn btn-success\">Edit material</a>    "
			contentsHTML += "<a href=\""+conLocation+"?action=delma&cid="+str(contentID)+"&mid="+str(editmenuitemID)+\
			"\" class=\"btn btn-danger\">Delete material</a></p>"

	contentsHTML += "</form>"

	return (resHeader+resHTML) % (menuitemsHTML, contentsHTML)

conLocation = "controller.py"