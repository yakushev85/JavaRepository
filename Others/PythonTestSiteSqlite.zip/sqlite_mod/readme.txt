Version 1.1
Required: Python 3, SQLite database, Bootstrap({SITE_ROOT}/bootstrap)